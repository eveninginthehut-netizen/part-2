﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pong
{
    public partial class Form1 : Form
    {
        //Игровые объекты
        int leftPaddleYey = 200;//LeftPaddleYey-левая ракетка
        int rightPaddleYey = 200;// RightPaddleYey-правая ракетка
        int ballX = 400;//Мяч X
        int ballY = 300;//Мяч Y
        int ballSpeedX = 5;//Скорость мяча X (по оси X)
        int ballSpeedY = 5;//Скорость мяча Y (по оси Y)
        int leftscore = 0;// Счет игрока слева
        int rightscore = 0;//Счет игрока справа
        bool gameRunning = true;//Игра активна
        Timer timer;//Таймер для анимации
        int aiSpeed = 3;

        public Form1()
        {
            InitializeComponent();
            //Настройка формы 
            this.Text = "Pong Game";//Устанавливаем имя окна
            this.Size = new Size(800, 600);//Устанавливаем размер нашего окна 
            this.StartPosition = FormStartPosition.CenterParent;//Начальное позиция окна, что бы она была по центру 
            this.DoubleBuffered = true; //Убирает мерцание 
            this.KeyPreview = true; //Свойство котрое позволяет приложению первым получать события с клавиатуры 
            //Подключаем событие 
            this.Paint += Form1_Paint;//Подключаем событие для адресcовки
            this.KeyDown += Form1_KeyDown;//Подключаем событие что бы считывать нажатие клавиш

            //Настраиваем таймер 
            timer = new Timer();//Создаем объект таймера
            timer.Interval = 16;//Устанавливем значение 16, для 60 кадров в секунду 

            timer.Tick += Timer_Tick;//Запускаем обновление игры для каждого кадра 
            timer.Start();//Запускаем таймер 
        }
        //Функция игры для обновления кажого кадра 
        private void Timer_Tick(object sender, EventArgs e)
        {
            if (gameRunning)
            {
                //Двигаем мяч
                ballX += ballSpeedX;//Двигаем мяч по оси X
                ballY += ballSpeedY;//Двигаем мяч по оси Y
                //Отскок от верха и низа 
                if (ballY <= 0 || ballY >= this.ClientSize.Height)
                {
                    ballSpeedY = -ballSpeedY;
                }
                //Отскок от левой ракетки 
                if (ballX<=50&&ballX>=30&&ballY>=leftPaddleYey&&ballY<=leftPaddleYey+100)
                {
                    ballSpeedX = -ballSpeedX;
                    ballX = 50;//Не даем мячу пройти сквозь ракетку
                }
                //Отскок от правой ракетки 
                if(ballX >= this.ClientSize.Width - 70 && ballX <= this.ClientSize.Width - 50 && ballY >= rightPaddleYey &&ballY<= rightPaddleYey + 100)
                {
                    ballSpeedX = -ballSpeedX;
                    ballX=this.ClientSize.Width - 70;
                }
                //Голл слева
                if (ballX<=0)
                {
                    rightscore++;
                    ResetBall();
                }
                //Голл справа
                if (ballX >= this.ClientSize.Width)
                {
                    leftscore++;
                    ResetBall();
                }
                //Проверка победы 
                if (leftscore >= 5 || rightscore >= 5)
                {
                    gameRunning = false;
                    timer.Stop();
                }
                //AI для правой ракетки
                if (rightPaddleYey + 50 < ballY)
                    rightPaddleYey += aiSpeed;
                else if (rightPaddleYey + 50 > ballY)
                    rightPaddleYey -= aiSpeed;
                    //Ограничеваем движение ракеток 
                    leftPaddleYey = Math.Max(0, Math.Min(this.ClientSize.Height - 100, leftPaddleYey));
                rightPaddleYey = Math.Max(0, Math.Min(this.ClientSize.Height - 100, rightPaddleYey));
            }
            this.Invalidate();//Перерисовываем
        }
        //Функция для сброса мяча после гола
        void ResetBall()
        {
            ballX = this.ClientSize.Width / 2;
            ballY=this.ClientSize.Height / 2;
            ballSpeedX = (new Random().Next(2) == 0) ? 5 : -5;//Задает случайное направление для мяча оси X
            ballSpeedY = (new Random().Next(2) == 0) ? 5 : -5;//Задает случайное направление для мяча оси Y
        }
        //Рисование игры
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;//Создаем объект Graphics, для доступа к элементам рисования
            g.FillRectangle(Brushes.Black, 0, 0, this.Width, this.Height);//Заливаем фон черным цветом 
            Pen whitePen = new Pen(Color.White, 3);//Создаем белую кисть 
            g.DrawLine(whitePen, this.Width / 2, 0, this.Width / 2, this.Height);//Рисуем центральную линию
            g.FillRectangle(Brushes.White, 30, leftPaddleYey, 15, 100);//Рисуем левую ракетку
            g.FillRectangle(Brushes.White, this.Width - 45, rightPaddleYey, 15, 100);//Рисуем правую ракетку
            g.FillEllipse(Brushes.White, ballX - 8, ballY - 8, 16, 16);
            //Рисуем счет
            Font font = new Font("Arial", 30); //Устанавливем стиль и размер шрифта
            g.DrawString(leftscore.ToString(), font, Brushes.White, this.Width / 4, 20);//Рисуем счет игрока слева в левом углу 
            g.DrawString(rightscore.ToString(), font, Brushes.White, 3 * this.Width / 4, 20);// Рисуем счет игрока справа в правом верхнем углу 
            //Если игра окончена, показываем победителя
            if (!gameRunning)
            {
                string winner = (leftscore >= 5) ? "Левый победител" : "Правый победитель";//Текст о победителе в переменную 
                g.DrawString(winner, font, Brushes.Yellow, this.Width / 2 - 100, this.Height / 2);//Адрессовываем имя победителя желтым цветом по середине экрана 
                g.DrawString("Нажмите R для перезапуска", new Font("Arial", 16), Brushes.White, this.Width / 2 - 120, this.Height / 2 + 50);//Адрессовываем текст, для информации о перезапуске 
            }
        }
        //Управление клавиатурой 
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //Левая ракетка W - вверх S - вниз
            if (e.KeyCode == Keys.W)
            {
                leftPaddleYey -= 20;//Если нажата W - вверх на 20px
            }
            if (e.KeyCode == Keys.S)//Если нажата S - ВНИЗ на 20px
            {
                leftPaddleYey += 20;
            }
            if (e.KeyCode == Keys.R)
            {
                leftscore = 0;
                rightscore = 0;
                ResetBall();
                timer.Start();
                //Если нажата буква R, мы обнуляем счет и перезапускаем игру 
            }
        }
    }
}